# Some themes what I done for [Alfred](http://www.alfredapp.com)
Feel free to use/remix as you wish. **[DOWNLOAD](https://github.com/iest/themes4alfred/releases/download/1.0.0/themes4alfred.zip)**

#### Yosemite Dark
![yosemite_dark](https://raw.github.com/iest/themes4alfred/master/yosemite_dark.png)

#### Yosemite
![yosemite](https://raw.github.com/iest/themes4alfred/master/yosemite.png)

#### Spacegrey Eighties
![spacegrey_eighties](https://raw.github.com/iest/themes4alfred/master/spacegray_eighties.png)

#### Spacegrey Ocean
![spacegrey_eighties](https://raw.github.com/iest/themes4alfred/master/spacegrey_ocean.png)

#### Gameboy
![gameboy](https://raw.github.com/iest/themes4alfred/master/gameboy.png)

#### Futura Clean
![futura clean](https://raw.github.com/iest/themes4alfred/master/futura_clean.png)

#### Espresso
![espresso](https://raw.github.com/iest/themes4alfred/master/espresso.png)

#### VHS
![VHS](https://raw.github.com/iest/themes4alfred/master/vhs.png)
